TUGAS AKHIR PWD
"Calls API using Axios"

Aplikasi yang saya buat dalam studi kasus adalah tentang Data Kelas dan CRUD-nya. Konsep dan caranya sama seperti yang ada di contoh. Hanya saja disini, saya meng-implementasikan ke dalam tabel kelas.

File yang ditambah :
1. KelasForm.vue
2. Kelas.vue
3. KelasController
4. Kelas.php

Tampilan awal :
1. Link Router untuk menambah data kelas
2. Tabel Kelas (No, Nama Kelas, Jurusan, Action{Edit, Delete})

Tampilan Form :
1. Nama Kelas + TextInput-nya
2. Jurusan + TextInput-nya
3. Tombol save